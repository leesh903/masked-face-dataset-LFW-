import numpy as np
import glob
from tensorflow.keras.preprocessing import image
import matplotlib.pyplot as plt
import random

train_ratio = 1.0
ver = 80 # (이미지 리사이즈 후) 세로 픽셀수
hor = 80 # (이미지 리사이즈 후) 가로 픽셀수
X_all_A = []
X_all_B = []
X_all_C = []


num_ID = 22
cnt = 0
X_all = None

for cnt in range(num_ID):
    #-------------------------------------------
    # 클래스 0번 속성 생성
    ID = str(cnt).zfill(2)
    path_A = ".\dataset_noblack\\A_ID" + ID
    
    filepath_oneID_A = sorted(glob.glob(path_A + "\*.jpg"))
    num_file = len(filepath_oneID_A)
    
    #---------------
    # 셔플
    idxdata = list(range(num_file))
    random.shuffle(idxdata)
    num_train = round(train_ratio * num_file)
    idx_train = idxdata[0:num_train]
    idx_test = idxdata[num_train:]
    #---------------
    
    # TRAINING SET
    X_A = [] # 비어있는 배열 생성
    for i, filepath_A in enumerate(filepath_oneID_A):
        
        if i in idx_train:
        
            img = image.load_img(filepath_A,                # 이미지의 실제 경로
                                 color_mode='rgb',  # 이미지를 무조건 흑백으로 불러오기
                                 target_size = (ver, hor)) # 세로100픽셀x가로100픽셀 사이즈로 이미지 불러오기
            img_array = image.img_to_array(img) # 이미지를 배열 형식으로 변환
            X_A.append(img_array) # 이미지를 하나씩 추가하여 한 클래스의 이미지 셋(집합) 생성
       
    X_array_oneID_A = np.array(X_A) # 한 클래스의 이미지 셋(list형)을 배열 형태로 변환 
    
    # 클래스 3번 정답 클래스 생성

    
    if cnt == 0:
        X_all_A = X_array_oneID_A

    else:
        X_all_A = np.concatenate((X_all_A, X_array_oneID_A), axis=0)    



    
    # TEST SET   
    # 클래스 0번 속성 생성
    ID = str(cnt).zfill(2)
    path_B = ".\dataset_noblack\\B_ID" + ID    

    filepath_oneID_B = sorted(glob.glob(path_B + "\*.jpg"))
    
    X_B = [] # 비어있는 배열 생성
    for j, filepath_B in enumerate(filepath_oneID_B):
        
        if j in idx_train:
        
            img = image.load_img(filepath_B,                # 이미지의 실제 경로
                                 color_mode='rgb',  # 이미지를 무조건 흑백으로 불러오기
                                 target_size = (ver, hor)) # 세로100픽셀x가로100픽셀 사이즈로 이미지 불러오기
            img_array = image.img_to_array(img) # 이미지를 배열 형식으로 변환
            X_B.append(img_array) # 이미지를 하나씩 추가하여 한 클래스의 이미지 셋(집합) 생성
       
    X_array_oneID_B = np.array(X_B) # 한 클래스의 이미지 셋(list형)을 배열 형태로 변환 
    
    # 클래스 3번 정답 클래스 생성

    
    if cnt == 0:
        X_all_B = X_array_oneID_B

    else:
        X_all_B = np.concatenate((X_all_B, X_array_oneID_B), axis=0)
  
    

#num_ID = 16
num_ID2 = 22
cnt2 = 0 
ID2 = 0    
   
for cnt2 in range(num_ID2):   
    
    # NEW SET   
    # 클래스 0번 속성 생성
    ID2 = str(cnt2).zfill(2)
    path_C = ".\dataset_noblack_test\\A_ID" + ID2    

    filepath_oneID_C = sorted(glob.glob(path_C + "\*.bmp"))

    
    X_C = [] # 비어있는 배열 생성
    for k, filepath_C in enumerate(filepath_oneID_C):
        
        img = image.load_img(filepath_C,                # 이미지의 실제 경로
                             color_mode='rgb',  # 이미지를 무조건 흑백으로 불러오기
                             target_size = (ver, hor)) # 세로100픽셀x가로100픽셀 사이즈로 이미지 불러오기
        img_array = image.img_to_array(img) # 이미지를 배열 형식으로 변환
        X_C.append(img_array) # 이미지를 하나씩 추가하여 한 클래스의 이미지 셋(집합) 생성
       
    X_array_oneID_C = np.array(X_C) # 한 클래스의 이미지 셋(list형)을 배열 형태로 변환 

    
    if cnt2 == 0:
        X_all_C = X_array_oneID_C

    else:
        X_all_C = np.concatenate((X_all_C, X_array_oneID_C), axis=0)   


np.save("file_dataA_1.npy", X_all_A)
np.save("file_dataB_1.npy", X_all_B)
np.save("file_dataC_1.npy", X_all_C)









