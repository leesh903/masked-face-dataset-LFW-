from tensorflow.keras.preprocessing import image
import matplotlib.pyplot as plt
import cv2
import numpy as np


ver = 80 # (이미지 리사이즈 후) 세로 픽셀수
hor = 80 # (이미지 리사이즈 후) 가로 픽셀수

for im in range(0,397):
#for im in range(5,6):
    ID = str(im).zfill(3)
    
    filename_test = './test_img/test_' + ID + '.jpg'
    filename_pred = './pred_img/pred_' + ID + '.jpg'
    filename_seg =  './seg_img/seg_' + ID + '.jpg'
    
    test_img = image.load_img(filename_test,                
                         color_mode='rgb',  
                         target_size = (ver, hor))
    
    pred_img = image.load_img(filename_pred,                
                         color_mode='rgb',  
                         target_size = (ver, hor))
    
    seg_img = image.load_img(filename_seg,                
                         color_mode='rgb',  
                         target_size = (ver, hor))
    
    
    test_img2 = np.array(test_img) # RGB로 불러오기
    pred_img2 = np.array(pred_img)
    seg_img2 = np.array(seg_img)
    seg_img3 = cv2.cvtColor(seg_img2, cv2.COLOR_RGB2GRAY) # RGB 2 GRAY
    
    #======================================================
    ret,thresh1 = cv2.threshold(seg_img3, 10,255,cv2.THRESH_BINARY)
    # 모폴로지 연산(침식 or 팽창)
    kernel_size_row = 5 # 이 값이 커질수록 침식 또는 팽창 효과가 강해집니다 (기본값 : 3)
    kernel_size_col = 5 # 이 값이 커질수록 침식 또는 팽창 효과가 강해집니다 (기본값 : 3)
    # 3, 5, 7등으로 값을 바꿔서 실행해보세요. cv2.erode()나 cv.dilate를 반복하여 적용하는 것도 가능합니다.
    kernel = np.ones((kernel_size_row, kernel_size_col), np.uint8)
    
    dilation_image = cv2.dilate(thresh1, kernel, iterations=2)  # 팽창연산이 적용된 이미지
                                                                 # iterations를 2 이상으로 설정하면 반복 적용됨            
    erosion_image = cv2.erode(dilation_image, kernel, iterations=2)  # 침식연산이 적용된 이미지
                                              # iterations를 2 이상으로 설정하면 반복 적용됨

    # 마스킹 (for face image)
    # bit 연산자를 통해 추출된 컬러만 표시한 이미지
    masking_1 = cv2.bitwise_and(test_img2, test_img2, mask=255-erosion_image)
    
    # 마스킹 (for face mask)
    masking_2 = cv2.bitwise_and(pred_img2, pred_img2, mask=erosion_image)
    
    result_img = masking_1 + masking_2    
    #======================================================
    savename_res = './res_img/res_' + ID + '.jpg'
    result_img2 = cv2.cvtColor(result_img,cv2.COLOR_RGB2BGR) # PIL 2 CV    
    cv2.imwrite(savename_res, result_img2) 
    
    # plt.imshow(seg_img3, cmap='gray')
    # plt.show()






