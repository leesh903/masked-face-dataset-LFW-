import numpy as np
import matplotlib.pyplot as plt
import time
import tensorflow as tf
#=============================
import random as rn

seed_num = 0
np.random.seed(seed_num)
rn.seed(seed_num)
tf.random.set_seed(seed_num)
#=============================

ver = 80
hor = 80

gpus = tf.config.experimental.list_physical_devices('GPU')
if gpus:
    try:
        # Currently, memory growth needs to be the same across GPUs
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        logical_gpus = tf.config.experimental.list_logical_devices('GPU')
        print(len(gpus), "Physical GPUs,", len(logical_gpus), "Logical GPUs")
    except RuntimeError as e:
        # Memory growth must be set before GPUs have been initialized
        print(e)
        
# 데이터셋 불러오기
#(x_train, x_test), (y_train, y_test) = np.load('dataset_facedb.npy', allow_pickle=True)
x_train = np.load('file_dataA_2.npy', allow_pickle=True)
x_test = np.load('file_dataB_2.npy', allow_pickle=True)
x_new = np.load('file_dataC_2.npy', allow_pickle=True)

# 학습용 속성 데이터
train_images = x_train.astype('float32') / 255 # 이미 형태가 갖춰졌으므로 reshape 과정은 필요 없음

# 테스트용 속성 데이터
test_images = x_test.astype('float32') / 255 # 이미 형태가 갖춰졌으므로 reshape 과정은 필요 없음

new_images = x_new.astype('float32') / 255 # 이미 형태가 갖춰졌으므로 reshape 과정은 필요 없음

print(train_images.shape, test_images.shape, new_images.shape)

def plot_images(nRow, nCol, img, cmap='gray'):
    fig = plt.figure()
    fig, ax = plt.subplots(nRow, nCol, figsize = (nCol,nRow))
    for i in range(nRow):
        for j in range(nCol):
            if nRow <= 1: axis = ax[j]
            else:         axis = ax[i, j]
            axis.get_xaxis().set_visible(False)
            axis.get_yaxis().set_visible(False)
            axis.imshow(img[i*nCol+j], cmap = cmap)
            
            
from tensorflow.keras import models
from tensorflow.keras import layers

enc_cnn = models.Sequential([
               layers.Conv2D(filters=16, kernel_size=3,
                                 activation='relu', input_shape=(ver,hor,3)),
               layers.Conv2D(filters=16, kernel_size=3, activation='relu'),
               layers.Flatten(),
               layers.Dense(225, activation='relu')])
enc_cnn.summary() 

dec_cnn = models.Sequential([
      layers.Dense((ver-4)*(hor-4)*16, input_shape=(225, ), activation='relu'),
      layers.Reshape(target_shape=(ver-4, hor-4, 16)),
      layers.Conv2DTranspose(filters=16, kernel_size=3, activation='relu'),
      layers.Conv2DTranspose(filters=3, kernel_size=3, activation='relu')])
dec_cnn.summary()


AE_CNN = models.Sequential([enc_cnn, dec_cnn])
AE_CNN.compile(loss = 'mse', optimizer='adam')
X_cnn = train_images.reshape(-1, ver, hor, 3)
X_cnn_2 = test_images.reshape(-1, ver, hor, 3)

#start = time.time()
history = AE_CNN.fit(X_cnn, X_cnn_2, batch_size = 20, epochs = 100)
#end = time.time() 
#print(f"{end - start:.5f} sec")


plt.plot(history.history['loss'], 'b-')

#------------------------------------------
samples = new_images

samples = samples.reshape(-1, ver, hor, 3)
start = time.time()
reduced = enc_cnn.predict(samples) # encoding
recovered = dec_cnn.predict(reduced) # decoding
end = time.time()
print(f"{end - start:.5f} sec")


#++++++++++++++++++++++++++++++++++
# save face images
num_img = np.shape(recovered)[0]
import cv2

for im in range(0, num_img):
    one_predimg = recovered[im,:,:,:]
    # one_predimg_255 = one_predimg * 255
    # one_predimg_255 = np.round(one_predimg_255)    
    one_predimg_1 = one_predimg / np.max(one_predimg)
    one_predimg_255 = np.round(one_predimg_1*255)
    #one_predimg_rgb = cv2.cvtColor(one_predimg_255, cv2.COLOR_BGR2RGB) # BGR 2 RGB
    ID = str(im).zfill(3)
    savename_pred = './seg_img/seg_' + ID + '.jpg'
    cv2.imwrite(savename_pred, one_predimg_255) 
#++++++++++++++++++++++++++++++++++






